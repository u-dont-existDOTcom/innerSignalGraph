# Inner Signal authoring proposal packet

Proposal: wisdom-practices-20260912

Status: candidate only. This packet preserves the current repository source family, exact candidate graph members, compiled graph bundle, provenance, regressions, and pending owner decisions. It cannot install without the existing owner-decision lifecycle.
