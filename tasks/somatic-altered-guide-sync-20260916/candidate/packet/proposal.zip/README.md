# Inner Signal authoring proposal packet

Proposal: somatic-altered-guide-sync-20260916

Status: candidate only. This packet preserves the current repository source family, exact candidate graph members, compiled graph bundle, provenance, regressions, and pending owner decisions. It cannot install without the existing owner-decision lifecycle.
